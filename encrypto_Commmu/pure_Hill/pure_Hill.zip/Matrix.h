#pragma once

#include "Librarys.h"

int* make_keyArray(int* key_size);
void keyElement_input(int* keyArray, int key_size);