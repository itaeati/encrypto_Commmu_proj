#pragma once

#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include <stdbool.h>
#define _USE_MATH_DEFINES
#include <math.h>

#define STR_SIZE 500
<<<<<<< HEAD
#define ALPABET_SIZE 26 // alphabet count
=======
#define ALPABET_SIZE 26 // ���� ���ĺ�

#define DEBUG
>>>>>>> origin/develop
